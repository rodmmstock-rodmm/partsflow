# PartsFlow Full Update — Requirement Consolidated

ชุดนี้อัปเดตเว็บตาม Requirement ที่สรุปร่วมกันทั้งหมด โดย **ไม่ตั้งใจลบข้อมูล Part / Inventory / History เดิม**

## สิ่งที่เพิ่มหลัก ๆ

- Dashboard Stock = Part & Stock รวมในหน้าเดียว
- Warehouse filter: `MM-4 = Phase4`, `MM-11 = Phase11`
- เพิ่ม/แก้ Part ทุก field ตาม Permission + ปรับ Stock แบบมี Transaction/Audit
- History: filter ผู้เบิก + ผู้บันทึกแยกกัน, edit/void ตาม Permission
- Safety Stock: ใช้ `Part.reorder_qty` เป็น "จำนวนที่ Order", ไม่แสดง Item ที่มี Active Order, Export Excel
- Order 5 หน้าย่อย:
  - Order Normal
  - Order Step / Project
  - รายการที่ต้องอัพเดต
  - Completed Order
  - Cancelled Order
- Order Status อัตโนมัติ:
  - ไม่มี Quotation → New Order
  - มี Quotation แต่ PO group ยังไม่ครบ → Wait Quotation
  - PO Number + Issue PR Date + Due Date ครบ → Wait for Item
  - กดรับของ → Complete Order
- ปุ่ม "รับของ" ใช้ Server Date-Time + Confirm
- ถ้ามี Item ID และ JOB = SPARE → รับเข้า Stock อัตโนมัติครั้งเดียว
- GROUP ORDER = `MACHINE_DATE` เช่น `BFD-01_21082026`
- งานด่วน / วันที่ค้าง DATA / Edit Data Workflow
- Order Project: Import Excel แต่ละครั้ง = Step ใหม่, ใช้/ไม่ได้ใช้, Summary มูลค่า
- Vendor CRUD ตาม Role
- Machine CRUD + Dept Code + Work Code ตาม Role
- Employee CRUD ใน Role & Permissions (Login ยังใช้ Employee Code ไม่มี Password)
- Permission ใหม่แยก Order Information / Purchase Information / Receive / Cancel / Project ฯลฯ
- Audit Log เก็บผู้แก้ไข, วันเวลา, ค่าเดิม/ค่าใหม่

---

## วิธีติดตั้ง — ทำทีละขั้น

### Step 1: แตก ZIP ไว้ในโฟลเดอร์ชั่วคราว

จาก Terminal ใน Codespace:

```bash
cd /workspaces/partsflow
mkdir -p /tmp/partsflow_full_update
unzip -o partsflow_full_update.zip -d /tmp/partsflow_full_update
```

### Step 2: ใช้ Script copy พร้อม Backup

```bash
bash /tmp/partsflow_full_update/apply_update.sh /workspaces/partsflow
```

Script จะสร้าง backup ไว้ใน:

```text
/workspaces/partsflow/backup_before_full_update_YYYYMMDD_HHMMSS
```

### Step 3: ตรวจ Python syntax ก่อน

```bash
cd /workspaces/partsflow/backend
python -m py_compile core/*.py core/management/commands/*.py
```

ถ้าไม่มี output = ผ่าน

### Step 4: Preview Migration ก่อน — ยังไม่เปลี่ยน Database

```bash
python manage.py makemigrations core --dry-run --verbosity 3
```

**หยุดตรงนี้ก่อน** แล้วดู output ว่าเป็นการ `Add field / Create model` ตามที่คาดหรือไม่

สิ่งที่ควรเห็นหลัก ๆ:

- Add `dept_code`, `work_code` to Machine
- Add recorder/void fields to StockTransaction
- Add permission fields to RoleAccess
- Create `JobType`
- Create `OrderProject`
- Create `OrderStep`
- Create `OrderRecord`
- Add Employee relation to AuditLog

ไม่ควรเห็นการลบ Part, Inventory, StockTransaction หรือข้อมูลหลักเดิม

### Step 5: ถ้า Preview ถูกต้อง ค่อยสร้าง Migration จริง

```bash
python manage.py makemigrations core
python manage.py migrate
```

### Step 6: เปิดสิทธิ์ ADMIN สำหรับฟังก์ชันใหม่

```bash
python manage.py seed_partsflow_admin_permissions
```

จากนั้น Logout/Login ใหม่ 1 ครั้ง

### Step 7: Frontend dependency + build check

```bash
cd /workspaces/partsflow/frontend
npm install
npm run build
```

ถ้าขึ้น `built in ...` = ผ่าน

### Step 8: รันเว็บทดสอบ

Terminal 1:

```bash
cd /workspaces/partsflow/backend
python manage.py runserver 0.0.0.0:8000
```

Terminal 2:

```bash
cd /workspaces/partsflow/frontend
npm run dev -- --host 0.0.0.0
```

เปิด Port 5173 จาก Codespaces

---

## Import ORDER เดิม (ทำภายหลังเมื่อเว็บผ่านแล้ว)

คำสั่งนี้ **ไม่แตะ Inventory** และมี Dry Run ก่อน:

```bash
cd /workspaces/partsflow/backend
python manage.py import_legacy_orders "/workspaces/partsflow/ROD MM STOCK.xlsx" --dry-run
```

ถ้ารายงานถูกต้องจึงค่อยรันจริงโดยเอา `--dry-run` ออก

> หมายเหตุ: รายการ Order เดิมที่มี Receive Date จะถูกนำเข้าเป็น Complete แต่ importer จะไม่บวก Stock ซ้ำ

---

## Order Step Excel

หน้า Order Step อ่านไฟล์ `.xlsx/.xls` จาก Browser แล้วสร้าง Step ใหม่ใน Project
Header ที่รองรับหลัก ๆ:

```text
DATE
FACTORY
MACHINE NAME
JOB
สถานะงานด่วน
วันที่งานค้าง
ITEM ID
PART NAME
PART DETAIL
MAKER
AMOUNT
UNIT
REMARK
ORDERED BY
QUOTATION
PO NUMBER
PRICE PER UNIT
VENDOR ORDER
LEAD TIME
ISSUE PR DATE
DUE DATE
VENDOR CONFIRM DATE
PERSON IN CHARGE OF ORDER
```

ฟิลด์ Purchase ไม่จำเป็นต้องมีในไฟล์ เพราะสามารถเติมทีหลังจากเว็บได้
