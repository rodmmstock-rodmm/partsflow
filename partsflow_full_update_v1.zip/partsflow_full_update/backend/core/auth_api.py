from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from .models import Employee, RoleAccess

PERMISSION_FIELDS = [
    "can_view_dashboard",
    "can_view_parts",
    "can_edit_parts",
    "can_adjust_stock",
    "can_receive_stock",
    "can_issue_stock",
    "can_view_history",
    "can_edit_history",
    "can_delete_history",
    "can_view_safety_stock",
    "can_view_orders",
    "can_add_order",
    "can_edit_order_info",
    "can_edit_purchase_info",
    "can_receive_order",
    "can_cancel_order",
    "can_delete_order",
    "can_update_edit_data",
    "can_manage_order_projects",
    "can_view_suppliers",
    "can_manage_suppliers",
    "can_view_machines",
    "can_manage_machines",
    "can_view_employees",
    "can_add_employees",
    "can_edit_employees",
    "can_view_audit_log",
    "can_manage_roles",
]


def permissions_for(employee):
    role = RoleAccess.objects.filter(
        role_name__iexact=(employee.role or ""), active=True
    ).first()
    if role:
        return {field: bool(getattr(role, field)) for field in PERMISSION_FIELDS}

    if (employee.role or "").strip().lower() in {"admin", "administrator"}:
        return {field: True for field in PERMISSION_FIELDS}

    defaults = {field: False for field in PERMISSION_FIELDS}
    defaults.update(
        {
            "can_view_dashboard": True,
            "can_view_parts": True,
            "can_view_history": True,
            "can_view_safety_stock": True,
        }
    )
    return defaults


def current_employee(request):
    pk = request.session.get("partsflow_employee_id")
    if not pk:
        return None
    employee = Employee.objects.filter(id=pk, active=True).first()
    if not employee:
        request.session.flush()
    return employee


def require_permission(request, permission=None):
    employee = current_employee(request)
    if not employee:
        return None, Response({"detail": "กรุณาเข้าสู่ระบบ"}, status=401)
    if permission and not permissions_for(employee).get(permission):
        return None, Response({"detail": "คุณไม่มีสิทธิ์ใช้งานส่วนนี้"}, status=403)
    return employee, None


def payload(employee):
    return {
        "id": str(employee.id),
        "employee_code": employee.employee_code,
        "name": employee.name,
        "role": employee.role or "",
        "department": employee.department or "",
        "permissions": permissions_for(employee),
    }


@csrf_exempt
@api_view(["POST"])
@permission_classes([AllowAny])
def login_view(request):
    code = str(request.data.get("employee_code", "")).strip()
    if not code:
        return Response({"detail": "กรุณากรอกรหัสพนักงาน"}, status=400)
    employee = Employee.objects.filter(
        employee_code__iexact=code, active=True
    ).first()
    if not employee:
        return Response(
            {"detail": "ไม่พบรหัสพนักงาน หรือบัญชีไม่ได้เปิดใช้งาน"},
            status=401,
        )
    request.session.cycle_key()
    request.session["partsflow_employee_id"] = str(employee.id)
    request.session.set_expiry(60 * 60 * 8)
    return Response({"authenticated": True, "employee": payload(employee)})


@api_view(["GET"])
@permission_classes([AllowAny])
def me_view(request):
    employee = current_employee(request)
    if not employee:
        return Response({"authenticated": False, "employee": None}, status=401)
    return Response({"authenticated": True, "employee": payload(employee)})


@csrf_exempt
@api_view(["POST"])
@permission_classes([AllowAny])
def logout_view(request):
    request.session.flush()
    return Response({"authenticated": False})
