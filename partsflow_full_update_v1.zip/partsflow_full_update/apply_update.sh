#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-/workspaces/partsflow}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$TARGET/backup_before_full_update_$STAMP"

if [ ! -d "$TARGET/backend" ] || [ ! -d "$TARGET/frontend" ]; then
  echo "ERROR: ไม่พบ backend/frontend ที่ $TARGET"
  exit 1
fi

mkdir -p "$BACKUP/backend/core" "$BACKUP/frontend/src"

FILES=(
  "backend/core/models.py"
  "backend/core/auth_api.py"
  "backend/core/role_api.py"
  "backend/core/stock_api.py"
  "backend/core/web_api.py"
  "backend/core/dashboard_api.py"
  "backend/core/order_api.py"
  "backend/core/audit_utils.py"
  "backend/core/web_urls.py"
  "frontend/package.json"
  "frontend/index.html"
  "frontend/vite.config.mjs"
  "frontend/src/App.jsx"
  "frontend/src/api.js"
  "frontend/src/auth.jsx"
  "frontend/src/main.jsx"
  "frontend/src/styles.css"
)

for rel in "${FILES[@]}"; do
  if [ -f "$TARGET/$rel" ]; then
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp "$TARGET/$rel" "$BACKUP/$rel"
  fi
done

if [ -d "$TARGET/frontend/src/pages" ]; then
  mkdir -p "$BACKUP/frontend/src/pages"
  cp -a "$TARGET/frontend/src/pages/." "$BACKUP/frontend/src/pages/" 2>/dev/null || true
fi
if [ -d "$TARGET/frontend/src/components" ]; then
  mkdir -p "$BACKUP/frontend/src/components"
  cp -a "$TARGET/frontend/src/components/." "$BACKUP/frontend/src/components/" 2>/dev/null || true
fi

cp -a "$HERE/backend/core/." "$TARGET/backend/core/"
cp -a "$HERE/frontend/." "$TARGET/frontend/"

echo ""
echo "Update files copied successfully."
echo "Backup: $BACKUP"
echo ""
echo "NEXT: อย่า migrate ทันที ให้รันคำสั่ง preview ตาม README_FIRST.md ก่อน"
