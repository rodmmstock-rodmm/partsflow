PartsFlow - Google Drive Relative Image Path Patch v1
====================================================

รองรับ Part.image_path ทั้ง 3 รูปแบบ:
1) URL รูปทั่วไป
2) Google Drive Share URL
3) Google Drive relative path เช่น
   DATA1_Images/G3D00001.PIC.113206.jpg

แนวทางของ patch:
- ค่า relative path ยังเก็บใน Database ตามเดิม ไม่แปลงข้อมูล 2,873 รายการ
- Django มี endpoint /api/parts/<id>/image/
- Backend ใช้ Google Drive API แบบ read-only เพื่อค้นไฟล์ตาม path และส่งรูปให้ browser
- ไม่ต้องเปิด DATA1_Images เป็น public ถ้าแชร์โฟลเดอร์ให้ Service Account เป็น Viewer
- Browser cache รูป 24 ชั่วโมง และ Backend cache file-id 12 ชั่วโมง

สิ่งที่ต้องตั้งครั้งเดียว:
A) Service Account JSON
   วางไว้ที่ backend/google-service-account.json
   ห้าม commit / ส่งไฟล์ JSON นี้ให้ผู้อื่น

B) แชร์โฟลเดอร์ DATA1_Images ให้ email ของ Service Account เป็น Viewer

C) Folder ID
   apply_patch.sh จะเพิ่ม GOOGLE_DRIVE_IMAGE_FOLDER_ID ลง backend/.env ให้อัตโนมัติ
   ถ้ามีค่าเดิมอยู่แล้ว script จะไม่ทับ

หลัง Apply Patch:
cd /workspaces/partsflow/backend
pip install -r requirements.txt
python manage.py check_drive_images --path "DATA1_Images/G3D00001.PIC.113206.jpg"
python manage.py check

จากนั้น:
cd /workspaces/partsflow/frontend
npm run build

ไม่มี Migration และไม่แก้ข้อมูล Stock/Order/History
