#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/partsflow}"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND="$ROOT/backend"
FRONTEND="$ROOT/frontend"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$ROOT/_backup_drive_path_$STAMP"

if [[ ! -d "$BACKEND/core" || ! -d "$FRONTEND/src" ]]; then
  echo "ERROR: ไม่พบโครงสร้าง PartsFlow ที่ $ROOT"
  exit 1
fi

mkdir -p "$BACKUP/backend/core/management/commands" "$BACKUP/frontend/src/pages" "$BACKUP/frontend/src/components"

for f in \
  "$BACKEND/core/web_api.py" \
  "$BACKEND/core/web_urls.py" \
  "$FRONTEND/src/pages/Dashboard.jsx" \
  "$FRONTEND/src/components/Common.jsx"; do
  if [[ -f "$f" ]]; then
    rel="${f#$ROOT/}"
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp "$f" "$BACKUP/$rel"
  fi
done

cp "$PATCH_DIR/backend/core/drive_images.py" "$BACKEND/core/drive_images.py"
cp "$PATCH_DIR/backend/core/web_api.py" "$BACKEND/core/web_api.py"
cp "$PATCH_DIR/backend/core/web_urls.py" "$BACKEND/core/web_urls.py"
mkdir -p "$BACKEND/core/management/commands"
cp "$PATCH_DIR/backend/core/management/commands/check_drive_images.py" "$BACKEND/core/management/commands/check_drive_images.py"
cp "$PATCH_DIR/frontend/src/pages/Dashboard.jsx" "$FRONTEND/src/pages/Dashboard.jsx"
cp "$PATCH_DIR/frontend/src/components/Common.jsx" "$FRONTEND/src/components/Common.jsx"

REQ="$BACKEND/requirements.txt"
if [[ -f "$REQ" ]]; then
  grep -q '^google-api-python-client' "$REQ" || echo 'google-api-python-client>=2.170' >> "$REQ"
  grep -q '^google-auth' "$REQ" || echo 'google-auth>=2.40' >> "$REQ"
fi

ENV_FILE="$BACKEND/.env"
DRIVE_FOLDER_ID='1dQ13uXJ2Mc6jn7B0jFAlk_0vy23BjrrU'
if [[ -f "$ENV_FILE" ]]; then
  if ! grep -q '^GOOGLE_DRIVE_IMAGE_FOLDER_ID=' "$ENV_FILE"; then
    printf '\nGOOGLE_DRIVE_IMAGE_FOLDER_ID=%s\n' "$DRIVE_FOLDER_ID" >> "$ENV_FILE"
  fi
else
  echo "หมายเหตุ: ไม่พบ $ENV_FILE — ให้เพิ่ม GOOGLE_DRIVE_IMAGE_FOLDER_ID ภายหลัง"
fi

GITIGNORE="$ROOT/.gitignore"
touch "$GITIGNORE"
grep -qxF 'backend/google-service-account.json' "$GITIGNORE" || echo 'backend/google-service-account.json' >> "$GITIGNORE"

cat <<EOF

============================================================
PartsFlow Drive Path Patch: applied successfully
============================================================
Backup: $BACKUP

ต่อไป:
1) cd $BACKEND
2) pip install -r requirements.txt
3) วาง Service Account JSON เป็น:
   $BACKEND/google-service-account.json
4) แชร์โฟลเดอร์ DATA1_Images ให้ email ของ Service Account เป็น Viewer
5) python manage.py check_drive_images --path "DATA1_Images/G3D00001.PIC.113206.jpg"
6) python manage.py check
7) cd $FRONTEND && npm run build
============================================================
EOF
