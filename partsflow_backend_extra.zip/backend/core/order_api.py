from decimal import Decimal, InvalidOperation

from django.db import IntegrityError, transaction
from django.db.models import Max, Q, Sum
from django.utils import timezone
from django.utils.dateparse import parse_date
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from .audit_utils import audit
from .auth_api import require_permission
from .models import (
    Employee,
    Inventory,
    Machine,
    OrderProject,
    OrderRecord,
    OrderStep,
    Part,
    StockTransaction,
    Supplier,
)

URGENT_OPTIONS = [
    "งานด่วนเครื่องหยุด",
    "งานด่วนเครื่องไม่หยุด",
    "งานด่วน + ค้าง DATA",
]


def as_date(value, label, required=False):
    if value in (None, ""):
        if required:
            raise ValueError(f"{label} จำเป็นต้องใส่")
        return None
    if hasattr(value, "year") and not isinstance(value, str):
        return value
    result = parse_date(str(value))
    if not result:
        raise ValueError(f"{label} ไม่ถูกต้อง")
    return result


def as_decimal(value, label, default="0"):
    try:
        return Decimal(str(value if value not in (None, "") else default))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError(f"{label} ไม่ถูกต้อง")


def employee_or_none(pk):
    return Employee.objects.filter(pk=pk, active=True).first() if pk else None


def machine_or_none(pk):
    return Machine.objects.filter(pk=pk, active=True).first() if pk else None


def supplier_or_none(pk):
    return Supplier.objects.filter(pk=pk, active=True).first() if pk else None


def part_or_none(pk):
    return Part.objects.select_related("maker", "unit", "location").filter(pk=pk, active=True).first() if pk else None


def generate_order_number(prefix="ORD"):
    return f"{prefix}-{timezone.localtime().strftime('%Y%m%d-%H%M%S-%f')}"


def group_order_for(order):
    if not (order.urgent_status or order.pending_data_date) or not order.machine:
        return ""
    return f"{order.machine.code}_{order.order_date.strftime('%d%m%Y')}"


def compute_status(order, validate=True):
    po_group = [bool(order.po_number), bool(order.issue_pr_date), bool(order.due_date)]
    if validate and any(po_group) and not all(po_group):
        raise ValueError("PO Number, ISSUE PR DATE และ DUE DATE ต้องใส่พร้อมกันทั้ง 3 ช่อง")
    if order.received_at:
        return OrderRecord.STATUS_COMPLETE
    if all(po_group):
        return OrderRecord.STATUS_ITEM
    if (order.quotation or "").strip():
        return OrderRecord.STATUS_QUOTE
    return OrderRecord.STATUS_NEW


def sync_system_fields(order, validate=True):
    if order.urgent_status == "งานด่วน + ค้าง DATA" and not order.pending_data_date:
        raise ValueError("เมื่อเลือก 'งานด่วน + ค้าง DATA' กรุณาระบุวันที่งานค้าง")
    order.group_order = group_order_for(order)
    order.price_total = Decimal(str(order.amount or 0)) * Decimal(str(order.price_per_unit or 0))
    order.status = compute_status(order, validate=validate)

    if order.source_type == "NORMAL" and order.pending_data_date and order.edit_workflow_enabled:
        if not order.edit_data_status:
            order.edit_data_status = OrderRecord.EDIT_WAIT_QUOTE
    elif not order.pending_data_date and order.edit_data_status != OrderRecord.EDIT_DONE:
        order.edit_data_status = ""


def order_json(order):
    return {
        "id": str(order.id),
        "order_number": order.order_number,
        "date": order.order_date.isoformat(),
        "factory": order.factory,
        "group_order": order.group_order,
        "machine_id": str(order.machine_id) if order.machine_id else "",
        "machine_code": order.machine.code if order.machine else "",
        "machine_name": order.machine.name if order.machine else "",
        "job": order.job,
        "urgent_status": order.urgent_status,
        "pending_data_date": order.pending_data_date.isoformat() if order.pending_data_date else "",
        "remark": order.remark,
        "quotation": order.quotation,
        "part_id": str(order.part_id) if order.part_id else "",
        "item_id": order.part.sku if order.part else "",
        "part_name": order.part_name,
        "part_detail": order.part_detail,
        "maker": order.maker_text,
        "amount": order.amount,
        "unit": order.unit_text,
        "po_number": order.po_number,
        "price_per_unit": float(order.price_per_unit or 0),
        "price_total": float(order.price_total or 0),
        "vendor_id": str(order.vendor_id) if order.vendor_id else "",
        "vendor_code": order.vendor.code if order.vendor else "",
        "vendor_name": order.vendor.name if order.vendor else "",
        "lead_time_days": order.lead_time_days,
        "ordered_by_id": str(order.ordered_by_id) if order.ordered_by_id else "",
        "ordered_by": order.ordered_by.name if order.ordered_by else "",
        "issue_pr_date": order.issue_pr_date.isoformat() if order.issue_pr_date else "",
        "due_date": order.due_date.isoformat() if order.due_date else "",
        "vendor_confirm_date": order.vendor_confirm_date.isoformat() if order.vendor_confirm_date else "",
        "received_at": timezone.localtime(order.received_at).isoformat() if order.received_at else "",
        "person_in_charge_id": str(order.person_in_charge_id) if order.person_in_charge_id else "",
        "person_in_charge": order.person_in_charge.name if order.person_in_charge else "",
        "recorded_by_id": str(order.recorded_by_id) if order.recorded_by_id else "",
        "recorded_by": order.recorded_by.name if order.recorded_by else "",
        "status": order.status,
        "cancel_status": order.cancel_status,
        "edit_data_status": order.edit_data_status,
        "source_type": order.source_type,
        "project_id": str(order.project_id) if order.project_id else "",
        "project_name": order.project.name if order.project else "",
        "step_id": str(order.step_id) if order.step_id else "",
        "step_no": order.step.step_no if order.step else None,
        "usage_status": order.usage_status,
        "stock_received": order.stock_received,
        "is_deleted": order.is_deleted,
        "created_at": timezone.localtime(order.created_at).isoformat(),
        "updated_at": timezone.localtime(order.updated_at).isoformat(),
    }


def apply_order_info(order, data, *, creating=False):
    if creating:
        order.order_date = timezone.localdate()
    # DATE cannot be edited after creation.
    if "factory" in data or creating:
        factory = str(data.get("factory") or "").strip()
        if factory not in {"MM-4", "MM-11"}:
            raise ValueError("FACTORY ต้องเป็น Phase4 หรือ Phase11")
        order.factory = factory

    if "machine_id" in data or creating:
        order.machine = machine_or_none(data.get("machine_id"))
        if not order.machine:
            raise ValueError("MACHINE NAME จำเป็นต้องใส่")

    if "job" in data or creating:
        order.job = str(data.get("job") or "").strip().upper()
        if not order.job:
            raise ValueError("JOB จำเป็นต้องใส่")

    if "urgent_status" in data or creating:
        urgent = str(data.get("urgent_status") or "").strip()
        if urgent and urgent not in URGENT_OPTIONS:
            raise ValueError("สถานะงานด่วนไม่ถูกต้อง")
        order.urgent_status = urgent

    if "pending_data_date" in data or creating:
        order.pending_data_date = as_date(data.get("pending_data_date"), "วันที่งานค้าง")

    if "part_id" in data or creating:
        order.part = part_or_none(data.get("part_id"))

    if order.part:
        order.part_name = order.part.name
        order.part_detail = order.part.description or ""
        order.maker_text = order.part.maker.name if order.part.maker else ""
        order.unit_text = order.part.unit.code if order.part.unit else ""
    else:
        if "part_name" in data or creating:
            order.part_name = str(data.get("part_name") or "").strip()
        if "part_detail" in data or creating:
            order.part_detail = str(data.get("part_detail") or "").strip()
        if "maker" in data or creating:
            order.maker_text = str(data.get("maker") or "").strip()
        if "unit" in data or creating:
            order.unit_text = str(data.get("unit") or "").strip()

    if not order.part_name:
        raise ValueError("Part Name จำเป็นต้องใส่")
    if not order.part_detail:
        raise ValueError("Part Detail จำเป็นต้องใส่")
    if not order.maker_text:
        raise ValueError("MAKER จำเป็นต้องใส่")
    if not order.unit_text:
        raise ValueError("Unit จำเป็นต้องใส่")

    if "amount" in data or creating:
        try:
            amount = int(data.get("amount") or 0)
        except (TypeError, ValueError):
            raise ValueError("AMOUNT ต้องเป็นจำนวนเต็ม")
        if amount <= 0:
            raise ValueError("AMOUNT ต้องมากกว่า 0")
        order.amount = amount

    if "remark" in data or creating:
        order.remark = str(data.get("remark") or "").strip()

    if "ordered_by_id" in data or creating:
        order.ordered_by = employee_or_none(data.get("ordered_by_id"))
        if not order.ordered_by:
            raise ValueError("ชื่อผู้สั่งจำเป็นต้องใส่")

    sync_system_fields(order)


def apply_purchase_info(order, data):
    if "quotation" in data:
        order.quotation = str(data.get("quotation") or "").strip()
    if "po_number" in data:
        order.po_number = str(data.get("po_number") or "").strip()
    if "price_per_unit" in data:
        price = as_decimal(data.get("price_per_unit"), "PRICE PER UNIT")
        if price < 0:
            raise ValueError("PRICE PER UNIT ต้องไม่น้อยกว่า 0")
        order.price_per_unit = price
    if "vendor_id" in data:
        order.vendor = supplier_or_none(data.get("vendor_id"))
    if "lead_time_days" in data:
        raw = data.get("lead_time_days")
        order.lead_time_days = None if raw in (None, "") else max(0, int(raw))
    if "issue_pr_date" in data:
        order.issue_pr_date = as_date(data.get("issue_pr_date"), "ISSUE PR DATE")
    if "due_date" in data:
        order.due_date = as_date(data.get("due_date"), "DUE DATE")
    if "vendor_confirm_date" in data:
        order.vendor_confirm_date = as_date(data.get("vendor_confirm_date"), "VENDOR CONFIRM DATE")
    if "person_in_charge_id" in data:
        order.person_in_charge = employee_or_none(data.get("person_in_charge_id"))
    sync_system_fields(order)


def order_queryset():
    return OrderRecord.objects.select_related(
        "machine",
        "part",
        "vendor",
        "ordered_by",
        "person_in_charge",
        "recorded_by",
        "project",
        "step",
    )


def urgency_class(order):
    urgent = bool(order.urgent_status)
    pending = bool(order.pending_data_date)
    if urgent and pending:
        return "urgent_pending"
    if urgent:
        return "urgent"
    if pending:
        return "pending"
    return "normal"


@csrf_exempt
@api_view(["GET", "POST"])
@permission_classes([AllowAny])
def orders(request):
    permission = "can_view_orders" if request.method == "GET" else "can_add_order"
    actor, err = require_permission(request, permission)
    if err:
        return err

    if request.method == "POST":
        try:
            with transaction.atomic():
                order = OrderRecord(
                    order_number=generate_order_number(),
                    order_date=timezone.localdate(),
                    recorded_by=actor,
                    source_type="NORMAL",
                    edit_workflow_enabled=True,
                )
                apply_order_info(order, request.data, creating=True)
                order.save()
                audit(actor, "CREATE", "OrderRecord", order.id, order_json(order_queryset().get(pk=order.pk)))
            return Response(order_json(order_queryset().get(pk=order.pk)), status=201)
        except (ValueError, IntegrityError) as exc:
            return Response({"detail": str(exc)}, status=400)

    view = str(request.GET.get("view", "normal")).strip().lower()
    q = str(request.GET.get("q", "")).strip()
    urgency = str(request.GET.get("urgency", "all")).strip().lower()
    job = str(request.GET.get("job", "")).strip().upper()
    status = str(request.GET.get("status", "")).strip()

    qs = order_queryset().filter(is_deleted=False, source_type="NORMAL")
    if view == "completed":
        qs = qs.filter(cancel_status=False, status=OrderRecord.STATUS_COMPLETE)
    elif view == "cancelled":
        qs = qs.filter(cancel_status=True)
    elif view == "updates":
        qs = qs.filter(cancel_status=False, pending_data_date__isnull=False, edit_workflow_enabled=True)
        qs = qs.filter(
            Q(edit_data_status=OrderRecord.EDIT_WAIT_QUOTE, status=OrderRecord.STATUS_QUOTE)
            | Q(edit_data_status=OrderRecord.EDIT_WAIT_ITEM, status=OrderRecord.STATUS_ITEM)
            | Q(edit_data_status=OrderRecord.EDIT_WAIT_COMPLETE, status=OrderRecord.STATUS_COMPLETE)
        )
    else:
        qs = qs.filter(cancel_status=False).exclude(status=OrderRecord.STATUS_COMPLETE)

    if q:
        qs = qs.filter(
            Q(order_number__icontains=q)
            | Q(part__sku__icontains=q)
            | Q(part_name__icontains=q)
            | Q(part_detail__icontains=q)
            | Q(maker_text__icontains=q)
            | Q(machine__code__icontains=q)
            | Q(machine__name__icontains=q)
            | Q(ordered_by__name__icontains=q)
        )
    if job:
        qs = qs.filter(job=job)
    if status:
        qs = qs.filter(status=status)

    rows = list(qs.order_by("-order_date", "-created_at")[:5000])
    if urgency in {"normal", "urgent", "pending", "urgent_pending"}:
        rows = [row for row in rows if urgency_class(row) == urgency]

    active_qs = order_queryset().filter(
        is_deleted=False,
        source_type="NORMAL",
        cancel_status=False,
    ).exclude(status=OrderRecord.STATUS_COMPLETE)
    active_rows = list(active_qs)
    job_core = {"REPAIR", "MODIFY", "AUTOMATION", "PM"}
    kpi = {
        "total": len(active_rows),
        "urgent": sum(1 for x in active_rows if urgency_class(x) == "urgent"),
        "urgent_pending": sum(1 for x in active_rows if urgency_class(x) == "urgent_pending"),
        "pending": sum(1 for x in active_rows if urgency_class(x) == "pending"),
        "repair": sum(1 for x in active_rows if x.job == "REPAIR"),
        "modify": sum(1 for x in active_rows if x.job == "MODIFY"),
        "automation": sum(1 for x in active_rows if x.job == "AUTOMATION"),
        "pm": sum(1 for x in active_rows if x.job == "PM"),
        "general": sum(1 for x in active_rows if x.job not in job_core),
    }
    return Response({"count": len(rows), "kpi": kpi, "results": [order_json(x) for x in rows]})


@api_view(["GET"])
@permission_classes([AllowAny])
def order_detail(request, pk):
    _, err = require_permission(request, "can_view_orders")
    if err:
        return err
    order = order_queryset().filter(pk=pk, is_deleted=False).first()
    if not order:
        return Response({"detail": "ไม่พบ Order"}, status=404)
    return Response(order_json(order))


@csrf_exempt
@api_view(["PATCH"])
@permission_classes([AllowAny])
def update_order_info(request, pk):
    actor, err = require_permission(request, "can_edit_order_info")
    if err:
        return err
    order = order_queryset().filter(pk=pk, is_deleted=False).first()
    if not order:
        return Response({"detail": "ไม่พบ Order"}, status=404)
    if order.received_at and order.stock_received:
        incoming_part = str(request.data.get("part_id", order.part_id or ""))
        current_part = str(order.part_id or "")
        incoming_job = str(request.data.get("job", order.job) or "").strip().upper()
        try:
            incoming_amount = int(request.data.get("amount", order.amount) or 0)
        except (TypeError, ValueError):
            incoming_amount = order.amount
        if incoming_part != current_part or incoming_job != (order.job or "").upper() or incoming_amount != order.amount:
            return Response({"detail": "Order นี้รับเข้า Stock แล้ว จึงไม่อนุญาตให้เปลี่ยน Item ID, JOB หรือ AMOUNT เพื่อป้องกัน Stock ไม่ตรง"}, status=400)
    before = order_json(order)
    try:
        with transaction.atomic():
            apply_order_info(order, request.data)
            order.save()
            after = order_json(order_queryset().get(pk=pk))
            audit(actor, "UPDATE_ORDER_INFO", "OrderRecord", order.id, {"before": before, "after": after})
        return Response(after)
    except ValueError as exc:
        return Response({"detail": str(exc)}, status=400)


@csrf_exempt
@api_view(["PATCH"])
@permission_classes([AllowAny])
def update_purchase_info(request, pk):
    actor, err = require_permission(request, "can_edit_purchase_info")
    if err:
        return err
    order = order_queryset().filter(pk=pk, is_deleted=False).first()
    if not order:
        return Response({"detail": "ไม่พบ Order"}, status=404)
    before = order_json(order)
    try:
        with transaction.atomic():
            apply_purchase_info(order, request.data)
            order.save()
            after = order_json(order_queryset().get(pk=pk))
            audit(actor, "UPDATE_PURCHASE_INFO", "OrderRecord", order.id, {"before": before, "after": after})
        return Response(after)
    except (ValueError, TypeError) as exc:
        return Response({"detail": str(exc)}, status=400)


def locked_inventory(part):
    rows = list(Inventory.objects.select_for_update().filter(part=part).order_by("pk"))
    if not rows:
        rows = [
            Inventory.objects.create(
                part=part,
                location=part.location,
                quantity=Decimal("0"),
                legacy_source="ORDER",
                legacy_id=f"ORDER:{part.sku}",
            )
        ]
    return rows


def stock_total(rows):
    return sum((Decimal(str(row.quantity or 0)) for row in rows), Decimal("0"))


def tx_no():
    return f"ORD-RCV-{timezone.now().strftime('%Y%m%d%H%M%S%f')}"


@csrf_exempt
@api_view(["POST"])
@permission_classes([AllowAny])
def receive_order(request, pk):
    actor, err = require_permission(request, "can_receive_order")
    if err:
        return err
    order = order_queryset().filter(pk=pk, is_deleted=False, cancel_status=False).first()
    if not order:
        return Response({"detail": "ไม่พบ Order หรือ Order ถูกยกเลิก"}, status=404)
    if order.received_at:
        return Response({"detail": "รายการนี้รับของแล้ว"}, status=400)

    try:
        with transaction.atomic():
            order = order_queryset().select_for_update().get(pk=pk)
            if order.received_at:
                raise ValueError("รายการนี้รับของแล้ว")

            stock_before = None
            stock_after = None
            tx = None
            if order.part_id and (order.job or "").upper() == "SPARE":
                part = Part.objects.select_for_update().select_related("location").get(pk=order.part_id)
                rows = locked_inventory(part)
                stock_before = stock_total(rows)
                row = rows[0]
                row.quantity = Decimal(str(row.quantity or 0)) + Decimal(str(order.amount))
                row.save(update_fields=["quantity", "updated_at"])
                stock_after = stock_before + Decimal(str(order.amount))
                tx = StockTransaction.objects.create(
                    legacy_source="ORDER",
                    legacy_id=str(order.id),
                    transaction_no=tx_no(),
                    part=part,
                    location=part.location,
                    transaction_type="RECEIVE",
                    quantity=Decimal(str(order.amount)),
                    recorded_by_employee=actor,
                    reference_type="ORDER",
                    reference_id=str(order.id),
                    transaction_date=timezone.now(),
                    remark=f"รับเข้าจาก Order {order.order_number}",
                    created_by=None,
                )
                order.stock_received = True
                order.stock_transaction = tx

            order.received_at = timezone.now()
            sync_system_fields(order)
            order.save()
            audit(
                actor,
                "RECEIVE_ORDER",
                "OrderRecord",
                order.id,
                {
                    "order_number": order.order_number,
                    "received_at": order.received_at.isoformat(),
                    "stock_added": bool(tx),
                    "stock_before": str(stock_before) if stock_before is not None else None,
                    "stock_after": str(stock_after) if stock_after is not None else None,
                    "stock_transaction_id": str(tx.id) if tx else None,
                },
            )
        return Response(order_json(order_queryset().get(pk=pk)))
    except ValueError as exc:
        return Response({"detail": str(exc)}, status=400)


@csrf_exempt
@api_view(["POST"])
@permission_classes([AllowAny])
def cancel_order(request, pk):
    actor, err = require_permission(request, "can_cancel_order")
    if err:
        return err
    order = order_queryset().filter(pk=pk, is_deleted=False).first()
    if not order:
        return Response({"detail": "ไม่พบ Order"}, status=404)
    target = bool(request.data.get("cancel", True))
    if target and order.received_at:
        return Response({"detail": "Order ที่รับของแล้วไม่สามารถยกเลิกได้"}, status=400)
    before = order.cancel_status
    order.cancel_status = target
    order.save(update_fields=["cancel_status", "updated_at"])
    audit(actor, "CANCEL_ORDER" if target else "RESTORE_ORDER", "OrderRecord", order.id, {"old": before, "new": target})
    return Response(order_json(order_queryset().get(pk=pk)))


@csrf_exempt
@api_view(["DELETE"])
@permission_classes([AllowAny])
def delete_order(request, pk):
    actor, err = require_permission(request, "can_delete_order")
    if err:
        return err
    order = order_queryset().filter(pk=pk, is_deleted=False).first()
    if not order:
        return Response({"detail": "ไม่พบ Order"}, status=404)
    before = order_json(order)
    order.is_deleted = True
    order.deleted_at = timezone.now()
    order.deleted_by_employee = actor
    order.save(update_fields=["is_deleted", "deleted_at", "deleted_by_employee", "updated_at"])
    audit(actor, "SOFT_DELETE", "OrderRecord", order.id, before)
    return Response({"success": True})


@csrf_exempt
@api_view(["POST"])
@permission_classes([AllowAny])
def update_edit_data(request, pk):
    actor, err = require_permission(request, "can_update_edit_data")
    if err:
        return err
    order = order_queryset().filter(pk=pk, is_deleted=False, cancel_status=False).first()
    if not order:
        return Response({"detail": "ไม่พบ Order"}, status=404)
    if not order.pending_data_date or not order.edit_workflow_enabled:
        return Response({"detail": "รายการนี้ไม่อยู่ใน Workflow แก้ไข Data"}, status=400)

    mapping = {
        OrderRecord.EDIT_WAIT_QUOTE: (OrderRecord.STATUS_QUOTE, OrderRecord.EDIT_WAIT_ITEM),
        OrderRecord.EDIT_WAIT_ITEM: (OrderRecord.STATUS_ITEM, OrderRecord.EDIT_WAIT_COMPLETE),
        OrderRecord.EDIT_WAIT_COMPLETE: (OrderRecord.STATUS_COMPLETE, OrderRecord.EDIT_DONE),
    }
    current = order.edit_data_status or OrderRecord.EDIT_WAIT_QUOTE
    if current not in mapping:
        return Response({"detail": "รายการนี้อัพเดตครบแล้ว"}, status=400)
    required_status, next_state = mapping[current]
    if order.status != required_status:
        return Response({"detail": f"Order ต้องอยู่สถานะ {required_status} ก่อนจึงจะกดอัพเดตได้"}, status=400)
    order.edit_data_status = next_state
    order.save(update_fields=["edit_data_status", "updated_at"])
    audit(actor, "UPDATE_EDIT_DATA", "OrderRecord", order.id, {"old": current, "new": next_state, "order_status": order.status})
    return Response(order_json(order_queryset().get(pk=pk)))


def project_json(project):
    orders = list(project.orders.filter(is_deleted=False).select_related("step"))
    used = [x for x in orders if x.usage_status == "USED"]
    return {
        "id": str(project.id),
        "name": project.name,
        "description": project.description or "",
        "active": project.active,
        "step_count": project.steps.count(),
        "total_items": len(orders),
        "used_items": len(used),
        "not_used_items": len(orders) - len(used),
        "total_order_value": float(sum((Decimal(str(x.price_total or 0)) for x in orders), Decimal("0"))),
        "used_value": float(sum((Decimal(str(x.price_total or 0)) for x in used), Decimal("0"))),
    }


@csrf_exempt
@api_view(["GET", "POST"])
@permission_classes([AllowAny])
def projects(request):
    permission = "can_view_orders" if request.method == "GET" else "can_manage_order_projects"
    actor, err = require_permission(request, permission)
    if err:
        return err
    if request.method == "GET":
        return Response({"results": [project_json(p) for p in OrderProject.objects.filter(active=True).order_by("-created_at")]})
    name = str(request.data.get("name", "")).strip()
    if not name:
        return Response({"detail": "กรุณาระบุชื่อ Project"}, status=400)
    try:
        project = OrderProject.objects.create(
            name=name,
            description=str(request.data.get("description", "")).strip(),
            created_by_employee=actor,
        )
    except IntegrityError:
        return Response({"detail": "ชื่อ Project นี้มีอยู่แล้ว"}, status=400)
    audit(actor, "CREATE", "OrderProject", project.id, project_json(project))
    return Response(project_json(project), status=201)


@api_view(["GET"])
@permission_classes([AllowAny])
def project_detail(request, pk):
    _, err = require_permission(request, "can_view_orders")
    if err:
        return err
    project = OrderProject.objects.filter(pk=pk, active=True).first()
    if not project:
        return Response({"detail": "ไม่พบ Project"}, status=404)
    steps = []
    for step in project.steps.order_by("step_no"):
        step_orders = list(order_queryset().filter(step=step, is_deleted=False).order_by("created_at"))
        steps.append(
            {
                "id": str(step.id),
                "step_no": step.step_no,
                "import_filename": step.import_filename,
                "created_at": timezone.localtime(step.created_at).isoformat(),
                "orders": [order_json(x) for x in step_orders],
            }
        )
    return Response({"project": project_json(project), "steps": steps})


def resolve_machine_from_row(row):
    machine_id = row.get("machine_id")
    if machine_id:
        return machine_or_none(machine_id)
    code = str(row.get("machine") or row.get("machine_code") or "").strip()
    if not code:
        return None
    return Machine.objects.filter(Q(code__iexact=code) | Q(name__iexact=code), active=True).first()


def resolve_employee_from_row(row, key="ordered_by"):
    pk = row.get(f"{key}_id")
    if pk:
        return employee_or_none(pk)
    text = str(row.get(key) or "").strip()
    if not text:
        return None
    return Employee.objects.filter(Q(employee_code__iexact=text) | Q(name__iexact=text), active=True).first()


def resolve_part_from_row(row):
    pk = row.get("part_id")
    if pk:
        return part_or_none(pk)
    sku = str(row.get("item_id") or "").strip()
    return Part.objects.select_related("maker", "unit", "location").filter(sku__iexact=sku, active=True).first() if sku else None


@csrf_exempt
@api_view(["POST"])
@permission_classes([AllowAny])
def import_project_step(request, pk):
    actor, err = require_permission(request, "can_manage_order_projects")
    if err:
        return err
    project = OrderProject.objects.filter(pk=pk, active=True).first()
    if not project:
        return Response({"detail": "ไม่พบ Project"}, status=404)
    rows = request.data.get("rows") or []
    if not isinstance(rows, list) or not rows:
        return Response({"detail": "ไม่พบรายการในไฟล์ Import"}, status=400)

    try:
        with transaction.atomic():
            current = project.steps.aggregate(max_no=Max("step_no"))["max_no"] or 0
            step = OrderStep.objects.create(
                project=project,
                step_no=current + 1,
                import_filename=str(request.data.get("filename") or "")[:255],
                imported_by_employee=actor,
            )
            created = []
            errors = []
            for idx, row in enumerate(rows, start=2):
                try:
                    machine = resolve_machine_from_row(row)
                    ordered_by = resolve_employee_from_row(row) or actor
                    part = resolve_part_from_row(row)
                    data = {
                        "date": row.get("date") or timezone.localdate().isoformat(),
                        "factory": row.get("factory") or "MM-4",
                        "machine_id": str(machine.id) if machine else "",
                        "job": row.get("job") or "",
                        "urgent_status": row.get("urgent_status") or "",
                        "pending_data_date": row.get("pending_data_date") or "",
                        "part_id": str(part.id) if part else "",
                        "part_name": row.get("part_name") or "",
                        "part_detail": row.get("part_detail") or "",
                        "maker": row.get("maker") or "",
                        "amount": row.get("amount") or 0,
                        "unit": row.get("unit") or "",
                        "remark": row.get("remark") or "",
                        "ordered_by_id": str(ordered_by.id),
                    }
                    order = OrderRecord(
                        order_number=generate_order_number("PRJ"),
                        order_date=timezone.localdate(),
                        recorded_by=actor,
                        source_type="PROJECT",
                        project=project,
                        step=step,
                        edit_workflow_enabled=False,
                        usage_status="USED",
                    )
                    apply_order_info(order, data, creating=True)
                    # Optional purchase fields if provided in project import.
                    purchase = {
                        k: row.get(k)
                        for k in [
                            "quotation",
                            "po_number",
                            "price_per_unit",
                            "vendor_id",
                            "lead_time_days",
                            "issue_pr_date",
                            "due_date",
                            "vendor_confirm_date",
                            "person_in_charge_id",
                        ]
                        if row.get(k) not in (None, "")
                    }
                    if purchase:
                        apply_purchase_info(order, purchase)
                    order.save()
                    created.append(order)
                except Exception as exc:
                    errors.append({"row": idx, "error": str(exc)})
            if not created:
                raise ValueError("ไม่มีรายการที่ Import สำเร็จ")
            audit(actor, "IMPORT_STEP", "OrderProject", project.id, {"step_no": step.step_no, "created": len(created), "errors": errors})
        return Response({"step_no": step.step_no, "created": len(created), "errors": errors, "project": project_json(project)})
    except ValueError as exc:
        return Response({"detail": str(exc)}, status=400)


@csrf_exempt
@api_view(["PATCH"])
@permission_classes([AllowAny])
def update_usage(request, pk):
    actor, err = require_permission(request, "can_manage_order_projects")
    if err:
        return err
    order = order_queryset().filter(pk=pk, source_type="PROJECT", is_deleted=False).first()
    if not order:
        return Response({"detail": "ไม่พบรายการ Project"}, status=404)
    status = str(request.data.get("usage_status") or "").strip().upper()
    if status not in {"USED", "NOT_USED"}:
        return Response({"detail": "สถานะต้องเป็น USED หรือ NOT_USED"}, status=400)
    before = order.usage_status
    order.usage_status = status
    order.save(update_fields=["usage_status", "updated_at"])
    audit(actor, "UPDATE_USAGE", "OrderRecord", order.id, {"old": before, "new": status})
    return Response(order_json(order_queryset().get(pk=pk)))
