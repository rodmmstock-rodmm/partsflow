PartsFlow - Google Drive OAuth Patch v2
======================================

เปลี่ยนการอ่านรูปจาก Service Account JSON เป็น OAuth 2.0 ของ Google Account
เพราะองค์กรบล็อกการสร้าง Service Account Key

สิ่งที่รองรับเหมือนเดิม:
- Part.image_path = DATA1_Images/G3D00001.PIC.113206.jpg
- Backend resolve path -> Google Drive file -> ส่งรูปให้ Dashboard
- Google Drive scope = drive.readonly เท่านั้น
- ไม่ต้องเปิด DATA1_Images เป็น public
- ไม่มี Migration และไม่แก้ Part / Inventory / History / Order

ไฟล์ลับที่ใช้ (ห้าม commit):
- backend/google-oauth-client.json  (OAuth Web Client ที่ดาวน์โหลดจาก Google Cloud)
- backend/google-drive-token.json   (สร้างอัตโนมัติหลังอนุญาต OAuth)

Codespaces:
OAuth Redirect URI ต้องเป็น Frontend port 5173 + /api/drive/oauth/callback/
เพราะ browser ใช้ session ของ PartsFlow ผ่าน Vite proxy

ตัวอย่าง:
https://YOUR-CODESPACE-5173.app.github.dev/api/drive/oauth/callback/

หลังตั้งค่าและ Apply patch:
python manage.py check_drive_images --path "DATA1_Images/G3D00001.PIC.113206.jpg"
