#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/partsflow}"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND="$ROOT/backend"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$ROOT/_backup_drive_oauth_$STAMP"

if [[ ! -d "$BACKEND/core" ]]; then
  echo "ERROR: ไม่พบ PartsFlow backend ที่ $BACKEND"
  exit 1
fi

mkdir -p "$BACKUP/backend/core/management/commands"
for f in \
  "$BACKEND/core/drive_images.py" \
  "$BACKEND/core/drive_oauth.py" \
  "$BACKEND/core/web_urls.py" \
  "$BACKEND/core/management/commands/check_drive_images.py"; do
  if [[ -f "$f" ]]; then
    rel="${f#$ROOT/}"
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp "$f" "$BACKUP/$rel"
  fi
done

cp "$PATCH_DIR/backend/core/drive_images.py" "$BACKEND/core/drive_images.py"
cp "$PATCH_DIR/backend/core/drive_oauth.py" "$BACKEND/core/drive_oauth.py"
cp "$PATCH_DIR/backend/core/web_urls.py" "$BACKEND/core/web_urls.py"
mkdir -p "$BACKEND/core/management/commands"
cp "$PATCH_DIR/backend/core/management/commands/check_drive_images.py" \
  "$BACKEND/core/management/commands/check_drive_images.py"

REQ="$BACKEND/requirements.txt"
touch "$REQ"
grep -q '^google-api-python-client' "$REQ" || echo 'google-api-python-client>=2.170' >> "$REQ"
grep -q '^google-auth' "$REQ" || echo 'google-auth>=2.40' >> "$REQ"
grep -q '^google-auth-oauthlib' "$REQ" || echo 'google-auth-oauthlib>=1.2' >> "$REQ"

ENV_FILE="$BACKEND/.env"
DRIVE_FOLDER_ID='1dQ13uXJ2Mc6jn7B0jFAlk_0vy23BjrrU'
if [[ -f "$ENV_FILE" ]]; then
  if ! grep -q '^GOOGLE_DRIVE_IMAGE_FOLDER_ID=' "$ENV_FILE"; then
    printf '\nGOOGLE_DRIVE_IMAGE_FOLDER_ID=%s\n' "$DRIVE_FOLDER_ID" >> "$ENV_FILE"
  fi
else
  printf 'GOOGLE_DRIVE_IMAGE_FOLDER_ID=%s\n' "$DRIVE_FOLDER_ID" > "$ENV_FILE"
fi

GITIGNORE="$ROOT/.gitignore"
touch "$GITIGNORE"
for x in \
  'backend/google-oauth-client.json' \
  'backend/google-drive-token.json' \
  'backend/google-service-account.json'; do
  grep -qxF "$x" "$GITIGNORE" || echo "$x" >> "$GITIGNORE"
done

cat <<EOF

============================================================
PartsFlow Google Drive OAuth Patch v2: applied successfully
============================================================
Backup: $BACKUP

ต่อไป:
1) pip install -r $BACKEND/requirements.txt
2) วาง OAuth Web Client JSON เป็น:
   $BACKEND/google-oauth-client.json
3) เพิ่ม GOOGLE_DRIVE_OAUTH_REDIRECT_URI=... ใน $BACKEND/.env
4) Restart Django
5) Login PartsFlow ด้วย ADMIN
6) เปิด /api/drive/oauth/start/ ผ่าน URL Frontend (port 5173)
7) อนุญาต Google Drive Read-only
8) python manage.py check_drive_images --path "DATA1_Images/G3D00001.PIC.113206.jpg"
============================================================
EOF
