#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-/workspaces/partsflow}"
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$ROOT/frontend/src/pages"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$ROOT/_backup_employee_name_only_$STAMP"
mkdir -p "$BACKUP/frontend/src/pages"
for f in Dashboard.jsx History.jsx Orders.jsx; do
  if [ -f "$DEST/$f" ]; then
    cp "$DEST/$f" "$BACKUP/frontend/src/pages/$f"
  fi
  cp "$SRC/frontend/src/pages/$f" "$DEST/$f"
done
echo "Patch applied successfully."
echo "Backup: $BACKUP"
