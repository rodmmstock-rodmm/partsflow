PartsFlow - Employee Name Only Patch

Changes:
- Employee dropdowns/autocomplete in Stock forms show employee name only.
- History requester/recorder filters and edit form show employee name only.
- Order "ชื่อผู้สั่ง", "ชื่อผู้บันทึก", and "PERSON IN CHARGE OF ORDER" show employee name only.
- Employee Code remains stored internally and remains visible where it is actually required, such as Login and Role & Permissions employee management.

Apply:
  cd /workspaces/partsflow
  unzip -o partsflow_employee_name_only_patch.zip -d /tmp/partsflow_employee_name_only_patch
  bash /tmp/partsflow_employee_name_only_patch/partsflow_employee_name_only_patch/apply_patch.sh /workspaces/partsflow

Then restart Vite if needed.
