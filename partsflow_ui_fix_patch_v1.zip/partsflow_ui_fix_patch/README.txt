PartsFlow UI Fix Patch

แก้ไข:
1) ฟอร์มเครื่องจักรแสดงเฉพาะ Machine Name (ไม่แสดง Machine Code)
   - เบิกอะไหล่
   - Order Information
   - Edit History
2) รูปอะไหล่รองรับ URL ปกติ และ Google Drive Share URL
   - Google Drive ต้องตั้ง Share = Anyone with the link
   - ระบบแปลง /file/d/... และ ?id=... เป็น thumbnail URL อัตโนมัติ
   - ถ้ารูปโหลดไม่ได้จะแสดงไอคอนกล่องแทน
3) Dashboard Stock
   - เพิ่มแถบเลื่อนซ้าย/ขวาด้านบนของตาราง และ sync กับตาราง
   - ลด/จำกัดความกว้าง Part Name และ Part Detail พร้อม wrap ข้อความ

ไม่มี Database migration และไม่แก้ข้อมูล Supabase
styles.css ใน patch เป็นไฟล์เต็มสำหรับแทนไฟล์เดิมทั้งหมด
