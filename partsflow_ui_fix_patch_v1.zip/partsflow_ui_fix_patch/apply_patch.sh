#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-/workspaces/partsflow}"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FRONT="$ROOT/frontend"
if [[ ! -d "$FRONT/src" ]]; then
  echo "ERROR: ไม่พบ $FRONT/src"
  exit 1
fi
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$ROOT/_backup_ui_fix_$STAMP"
mkdir -p "$BACKUP/frontend/src/pages" "$BACKUP/frontend/src/components"
for f in pages/Dashboard.jsx pages/History.jsx pages/Orders.jsx components/Common.jsx styles.css; do
  if [[ -f "$FRONT/src/$f" ]]; then
    mkdir -p "$BACKUP/frontend/src/$(dirname "$f")"
    cp "$FRONT/src/$f" "$BACKUP/frontend/src/$f"
  fi
done
cp "$PATCH_DIR/frontend/src/pages/Dashboard.jsx" "$FRONT/src/pages/Dashboard.jsx"
cp "$PATCH_DIR/frontend/src/pages/History.jsx" "$FRONT/src/pages/History.jsx"
cp "$PATCH_DIR/frontend/src/pages/Orders.jsx" "$FRONT/src/pages/Orders.jsx"
cp "$PATCH_DIR/frontend/src/components/Common.jsx" "$FRONT/src/components/Common.jsx"
cp "$PATCH_DIR/frontend/src/styles.css" "$FRONT/src/styles.css"
echo "OK: PartsFlow UI Fix applied"
echo "Backup: $BACKUP"
echo "Next: cd $FRONT && npm run build"
