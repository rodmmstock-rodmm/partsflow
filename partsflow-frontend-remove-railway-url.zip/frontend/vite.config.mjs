import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Production API routing lives in src/api.js (Render backend by default).
// Do not inject VITE_API_BASE_URL here: doing so at build time overrides the
// real environment value, which broke the Local Edition "/api" override and
// pointed non-*.vercel.app hosts at the retired Railway service.
export default defineConfig({
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 5173,
    proxy: {
      "/api": {
        target: "http://127.0.0.1:8000",
        changeOrigin: true,
      },
    },
  },
});
